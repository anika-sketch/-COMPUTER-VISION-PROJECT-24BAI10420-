"""
Unit tests for EAR/MAR formulas, validated against hand-computed landmark
coordinates (as documented in README.md's "Instructions for Testing").
"""

import math
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from feature_extractor import FeatureExtractor


def test_ear_open_eye_is_high():
    # A roughly "open" eye: wide horizontally, non-trivial vertical gap
    eye = [(0, 5), (2, 2), (4, 2), (6, 5), (4, 8), (2, 8)]
    ear = FeatureExtractor.compute_EAR(eye)
    assert ear > 0.4, f"Expected an open eye to have EAR > 0.4, got {ear}"


def test_ear_closed_eye_is_low():
    # A "closed" eye: eyelid points collapsed onto each other (near-zero height)
    eye = [(0, 5), (2, 5), (4, 5), (6, 5), (4, 5.05), (2, 5.05)]
    ear = FeatureExtractor.compute_EAR(eye)
    assert ear < 0.05, f"Expected a closed eye to have EAR near 0, got {ear}"


def test_ear_hand_computed_value():
    # Hand-computed: p1=(0,0) p4=(10,0) -> horizontal = 10
    # p2=(2,-3) p6=(2,3) -> vertical_1 = 6 ; p3=(8,-3) p5=(8,3) -> vertical_2 = 6
    # EAR = (6 + 6) / (2 * 10) = 0.6
    eye = [(0, 0), (2, -3), (8, -3), (10, 0), (8, 3), (2, 3)]
    ear = FeatureExtractor.compute_EAR(eye)
    assert math.isclose(ear, 0.6, rel_tol=1e-6), f"Expected EAR=0.6, got {ear}"


def test_ear_requires_six_points():
    try:
        FeatureExtractor.compute_EAR([(0, 0), (1, 1)])
        assert False, "Expected ValueError for wrong number of eye landmarks"
    except ValueError:
        pass


def test_mar_hand_computed_value():
    # horizontal p1=(0,0) p5=(20,0) -> 20
    # verticals: (2,-2)-(2,2)=4 ; (2,-3)-(2,3)? use symmetric example below.
    mouth = [
        (0, 0),    # p1 left corner
        (4, -2), (8, -3), (12, -2),  # p2, p3, p4 (top lip)
        (20, 0),   # p5 right corner
        (12, 2), (8, 3), (4, 2),    # p6, p7, p8 (bottom lip)
    ]
    mar = FeatureExtractor.compute_MAR(mouth)
    # vertical_1 = |p2-p8| = |(-2)-2| = 4 ; vertical_2 = |p3-p7| = |(-3)-3| = 6
    # vertical_3 = |p4-p6| = |(-2)-2| = 4 ; horizontal = 20
    # MAR = (4+6+4) / (2*20) = 14/40 = 0.35
    assert math.isclose(mar, 0.35, rel_tol=1e-6), f"Expected MAR=0.35, got {mar}"


def test_mar_requires_eight_points():
    try:
        FeatureExtractor.compute_MAR([(0, 0)] * 4)
        assert False, "Expected ValueError for wrong number of mouth landmarks"
    except ValueError:
        pass


def test_bbox_fallback_ratios():
    fe = FeatureExtractor()
    assert fe.estimate_ear_from_bbox(10, 5) == 0.5
    assert fe.estimate_mar_from_bbox(20, 10) == 0.5
    assert fe.estimate_ear_from_bbox(0, 5) == 0.0


def test_history_smoothing():
    fe = FeatureExtractor(history_len=5)
    for v in [0.1, 0.2, 0.3, 0.4, 0.5]:
        fe.push(v, v)
    assert math.isclose(fe.smoothed_ear(window=5), 0.3, rel_tol=1e-6)


ALL_TESTS = [
    test_ear_open_eye_is_high,
    test_ear_closed_eye_is_low,
    test_ear_hand_computed_value,
    test_ear_requires_six_points,
    test_mar_hand_computed_value,
    test_mar_requires_eight_points,
    test_bbox_fallback_ratios,
    test_history_smoothing,
]

if __name__ == "__main__":
    for t in ALL_TESTS:
        t()
        print(f"PASS: {t.__name__}")
