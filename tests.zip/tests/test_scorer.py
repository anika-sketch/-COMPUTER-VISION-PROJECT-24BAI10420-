"""
Validation tests for DrowsinessScorer's threshold/state-transition logic
(Normal -> Drowsy -> Normal) using synthetic EAR/MAR/tilt sequences, as
documented in README.md's testing section.
"""

import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from scorer import DrowsinessScorer, DriverState


def _scorer(consecutive_frames=5):
    return DrowsinessScorer(
        ear_threshold=0.21, mar_threshold=0.55, head_tilt_threshold_deg=25.0,
        ear_weight=0.5, mar_weight=0.3, pose_weight=0.2,
        consecutive_frames=consecutive_frames,
    )


def test_stays_normal_with_open_eyes():
    s = _scorer()
    for _ in range(30):
        result = s.classify_state(ear=0.32, mar=0.10, tilt_deg=0.0)
    assert result.state == DriverState.NORMAL


def test_single_frame_blink_does_not_trigger_alert():
    """A single closed-eye frame (normal blink) must NOT trigger Drowsy."""
    s = _scorer(consecutive_frames=10)
    for _ in range(9):
        result = s.classify_state(ear=0.32, mar=0.10, tilt_deg=0.0)
    result = s.classify_state(ear=0.05, mar=0.10, tilt_deg=0.0)  # 1 closed frame
    assert result.state == DriverState.NORMAL, "A single blink frame should not raise an alert"


def test_sustained_eye_closure_triggers_drowsy():
    s = _scorer(consecutive_frames=10)
    result = None
    for _ in range(10):
        result = s.classify_state(ear=0.05, mar=0.10, tilt_deg=0.0)
    assert result.state == DriverState.DROWSY


def test_recovers_to_normal_after_drowsy():
    s = _scorer(consecutive_frames=5)
    for _ in range(5):
        s.classify_state(ear=0.05, mar=0.10, tilt_deg=0.0)
    assert s.current_state == DriverState.DROWSY
    for _ in range(3):
        result = s.classify_state(ear=0.30, mar=0.10, tilt_deg=0.0)
    assert result.state == DriverState.NORMAL


def test_sustained_head_turn_triggers_distracted():
    s = _scorer(consecutive_frames=8)
    result = None
    for _ in range(8):
        result = s.classify_state(ear=0.30, mar=0.10, tilt_deg=40.0)
    assert result.state == DriverState.DISTRACTED


def test_yawning_contributes_to_drowsy_state():
    s = _scorer(consecutive_frames=6)
    result = None
    for _ in range(6):
        result = s.classify_state(ear=0.30, mar=0.90, tilt_deg=0.0)
    assert result.state == DriverState.DROWSY


def test_score_is_bounded_between_0_and_1():
    s = _scorer()
    for ear, mar, tilt in [(0.0, 2.0, 90.0), (1.0, 0.0, 0.0), (0.21, 0.55, 25.0)]:
        result = s.classify_state(ear, mar, tilt)
        assert 0.0 <= result.score <= 1.0


def test_reset_clears_state():
    s = _scorer(consecutive_frames=3)
    for _ in range(3):
        s.classify_state(ear=0.05, mar=0.10, tilt_deg=0.0)
    assert s.current_state == DriverState.DROWSY
    s.reset()
    assert s.current_state == DriverState.NORMAL


ALL_TESTS = [
    test_stays_normal_with_open_eyes,
    test_single_frame_blink_does_not_trigger_alert,
    test_sustained_eye_closure_triggers_drowsy,
    test_recovers_to_normal_after_drowsy,
    test_sustained_head_turn_triggers_distracted,
    test_yawning_contributes_to_drowsy_state,
    test_score_is_bounded_between_0_and_1,
    test_reset_clears_state,
]

if __name__ == "__main__":
    for t in ALL_TESTS:
        t()
        print(f"PASS: {t.__name__}")
