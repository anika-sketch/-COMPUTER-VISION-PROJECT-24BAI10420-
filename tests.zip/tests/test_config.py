import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from config import AppConfig


def test_default_config_is_valid():
    AppConfig().validate()  # should not raise


def test_invalid_ear_threshold_rejected():
    try:
        AppConfig(ear_threshold=1.5).validate()
        assert False, "Expected ValueError for ear_threshold out of range"
    except ValueError:
        pass


def test_weights_must_sum_to_one():
    try:
        AppConfig(ear_weight=0.5, mar_weight=0.5, pose_weight=0.5).validate()
        assert False, "Expected ValueError when weights don't sum to 1.0"
    except ValueError:
        pass


ALL_TESTS = [test_default_config_is_valid, test_invalid_ear_threshold_rejected, test_weights_must_sum_to_one]

if __name__ == "__main__":
    for t in ALL_TESTS:
        t()
        print(f"PASS: {t.__name__}")
